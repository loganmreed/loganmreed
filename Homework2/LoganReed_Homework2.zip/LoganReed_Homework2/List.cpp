//
//  List.cpp
//  DoublyLinkedList
//
//  Created by Madhuri Debnath on 9/24/20.
//

#include<iostream>
#include "List.h"
using namespace std;

void List::insert(int value)
{
    Node* newNode = new Node(value);
    if (!headPtr){ // empty list
        headPtr = newNode;
        tailPtr = newNode;
    } else {
        tailPtr->setNextPtr(newNode);
        newNode->setPrevPtr(tailPtr);
        tailPtr = newNode;
    }
}

void List::insertAtIndex(int data, int index)
{
    Node* newNode = new Node(data);
    if (index == 0){ // insert at head
        newNode->setNextPtr(headPtr);
        if(headPtr) headPtr->setPrevPtr(newNode);
        headPtr = newNode;
        if(!tailPtr) tailPtr = newNode;
        return;
    }
    Node* temp = headPtr;
    int i = 0;
    while (temp && i < index - 1){
        temp = temp->getNextPtr();
        i++;
    }
    if(!temp){
        insert(data);
        return;
    }
    newNode->setNextPtr(temp->getNextPtr());
    newNode->setPrevPtr(temp);
    if (temp->getNextPtr())
        temp->getNextPtr()->setPrevPtr(newNode);
    else
        tailPtr = newNode; // inserting at end
    temp->setNextPtr(newNode);

}
void List::deleteAtIndex(int index)
{
    if (!headPtr) return; // empty

    Node* temp = headPtr;
    int i = 0;
    while (temp && i < index) {
        temp = temp->getNextPtr();
        i++;
    }
    if (!temp) return; // index out of range

    if (temp->getPrevPtr())
        temp->getPrevPtr()->setNextPtr(temp->getNextPtr());
    else
        headPtr = temp->getNextPtr(); // deleting head

    if (temp->getNextPtr()){
        temp->getNextPtr()->setPrevPtr(temp->getPrevPtr());
    }else{
        tailPtr = temp->getPrevPtr(); // deleting tail
    }
    delete temp;
}

void List::readItem(int index)
{
    Node* temp = headPtr;
    int i = 0;
    while (temp && i < index) {
        temp = temp->getNextPtr();
        i++;
    }
    if (temp)
        cout << "Item at index " << index << ": " << temp->getData() << endl;
    else
        cout << "Index out of range." << endl;
}

void List::reverseList()
{
    Node* current = headPtr;
    Node* temp = nullptr;

    while (current) {
        temp = current->getPrevPtr();
        current->setPrevPtr(current->getNextPtr());
        current->setNextPtr(temp);
        current = current->getPrevPtr();
    }
    if (temp) {
        tailPtr = headPtr;
        headPtr = temp->getPrevPtr();
    }
}

void List::printForward()
{
    Node* temp = headPtr;
    while (temp) {
        cout << temp->getData() << " ";
        temp = temp->getNextPtr();
    }
    cout << endl;
}

void List::printBackward()
{
    Node* temp = tailPtr;
    while (temp) {
        cout << temp->getData() << " ";
        temp = temp->getPrevPtr();
    }
    cout << endl;
}

