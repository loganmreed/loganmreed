const character = document.getElementById('character');
const platform = document.getElementById('platform');
const gravity = 9.8; // Acceleration due to gravity
const floorY = platform.offsetTop; // Y position of the floor

// box grid and box details
const gridSizeX = 64; // Horizontal grid cell size (in pixels)
const gridSizeY = 72; // Vertical grid cell size (in pixels)
const boxWidth = 60; // Box width (in pixels)
const boxHeight = 70; // Box height (in pixels)
const marginBottomPercentage = 0.07; // 7% margin from the bottom of the screen
const screenHeight = window.innerHeight;
const marginBottom = screenHeight * marginBottomPercentage; // 7% margin from the bottom

// Calculate the number of rows considering the margin
const availableHeight = screenHeight - marginBottom; // Height excluding bottom margin
const rows = Math.floor(availableHeight / boxHeight); // Number of rows based on available height
const columns = Math.floor(window.innerWidth / gridSizeX); // Number of columns based on screen width

const occupied = Array(columns).fill(0); // Array to track the lowest available row in each column
const boxes = []; // Track all placed boxes

let keys = {}; // Track key states
let characterVelocity = { x: 0, y: 0 }; // Character's velocity
let characterMass = 10; // Player's mass
let onGround = true; // Whether the character is on the ground

// Settings for movement
let speed = 5; // Base speed for movement
let airControlFactor = 0.5; // Reduced control when airborne

// Event listeners for movement
document.addEventListener('keydown', (e) => (keys[e.code] = true));
document.addEventListener('keyup', (e) => (keys[e.code] = false));

// Window resize listener
window.addEventListener('resize', adjustSpeed);

// Update loop
function gameLoop() {
    handleCharacterMovement();
    applyPhysics();
    checkCollisions();
    updateCharacterPosition();
    requestAnimationFrame(gameLoop);
}

// Handle character movement based on key inputs
function handleCharacterMovement() {
    if (keys['ArrowLeft']) {
        characterVelocity.x = onGround ? -speed : -speed * airControlFactor;
        character.classList.add('walking-x');
        character.style.transform = 'rotateY(70deg)';
    } else if (keys['ArrowRight']) {
        characterVelocity.x = onGround ? speed : speed * airControlFactor;
        character.classList.add('walking-x');
        character.style.transform = 'rotateY(-70deg)';
    } else {
        characterVelocity.x = 0;
        character.classList.remove('walking-x');
        character.style.transform = 'rotateY(45deg)';
    }

    if (keys['Space'] && onGround) {
        characterVelocity.y = -20; // Stronger jump due to higher mass
        onGround = false;
    }
}

// Apply physics to the character
function applyPhysics() {
    characterVelocity.y += gravity * characterMass * 0.016; // Simulate gravity
}

// Update character's position based on velocity
function updateCharacterPosition() {
    const nextPosition = {
        x: character.offsetLeft + characterVelocity.x,
        y: character.offsetTop + characterVelocity.y,
    };

    // Check for landing (check if the character hits the floor)
    if (nextPosition.y + character.offsetHeight >= floorY) {
        nextPosition.y = floorY - character.offsetHeight;
        characterVelocity.y = 0;
        onGround = true;
    }

    // Update position
    character.style.left = `${nextPosition.x}px`;
    character.style.top = `${nextPosition.y}px`;
}

// Dynamically adjust character speed based on window width
function adjustSpeed() {
    speed = window.innerWidth / 200; // Adjust speed proportionally to window width
}

// Check for collision with boxes
function checkCollisions() {

    const characterBounds = character.getBoundingClientRect();

console.log({characterStart: characterBounds.top})

    // Check against each box in the boxes array
    boxes.forEach((box) => {
        const boxBounds = box.getBoundingClientRect();

        // Check for collision in all four directions: left, right, top, bottom
        if (
            characterBounds.left < boxBounds.right &&
            characterBounds.right > boxBounds.left &&
            characterBounds.top < boxBounds.bottom &&
            characterBounds.bottom > boxBounds.top
        ) {
            // Collision detected, resolve it based on the side of impact
            if (characterBounds.bottom > boxBounds.top && characterBounds.top < boxBounds.top) {
                console.log(characterBounds.top, boxBounds.top)
                // If falling, stop falling
                characterVelocity.y = 0;
                onGround = true;
                character.style.top = `${boxBounds.top - character.offsetHeight}px`;
            } 
        }
    });
}

document.body.addEventListener('click', function (event) {
    // Determine the column based on the click position
    const column = Math.floor(event.pageX / gridSizeX);

    // Find the lowest available row in the column
    const row = occupied[column];

    // If the column is not full (within the available height), create a new box
    if (row < rows) {
        const box = document.createElement('div');
        box.classList.add('box');
        
        // Set the position of the box in the grid (column and row)
        const x = column * gridSizeX;
        const y = screenHeight - marginBottom - (row + 1) * gridSizeY;

        box.style.left = `${x}px`;
        box.style.top = `${y}px`;

        document.body.appendChild(box);

        // Update the occupied row for that column
        occupied[column]++;
        boxes.push(box);
    }
});

// Start the game loop
gameLoop();
